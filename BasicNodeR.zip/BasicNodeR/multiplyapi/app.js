//Con esta linea llamamos a la librería de express
const express = require('express');
//Con esta linea llmamos a la librería de cors
const cors = require('cors');
//Con esta linea creamos una instancia de express
const app = express()
//middleware aquí se llaman
//con esta línea le decimos a express que vamos a usar cors
app.use(cors());
//con esta línea le decimos a express que vamos a usar json
app.use(express.json());
//esta es la función que se ejecuta cuando se haga
//la petición a la ruta raíz
app.post('/multiplicar', (req, res) => {
  const { a, b } = req.body;
  const resultado = Number(a) * Number(b);
  res.json({ resultado });
});
//esta función es la que crea el servidor
app.listen(3000, () => {
  console.log('API ejecutándose en http://localhost:3000');
});
