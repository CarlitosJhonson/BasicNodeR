const express = require('express');
const cors = require('cors');
const app = express()
app.use(cors())

const personas = [
  { id: 1, identificacion: '123456', nombres: 'Pepito Perez',telefono: '3111234567', correo: 'pepito@mail.com',fechaNacimiento: '1990-05-10', sexo: 'F' },

  { id: 2, identificacion: '654321', nombres: 'Juanito Pérez',telefono: '3109876543', correo: 'jp@mail.com', fechaNacimiento: '1985-08-20', sexo: 'M' },

  { id: 3, identificacion: '111111', nombres: 'Pedro Navaja',telefono: '3131111111', correo: 'marta@mail.com',fechaNacimiento: '1992-07-15', sexo: 'F' },

  { id: 4, identificacion: '222222', nombres: 'Andrea Mejía',telefono: '3122222222', correo: 'carlos@mail.com',fechaNacimiento: '1980-01-05', sexo: 'M' },

  { id: 5, identificacion: '333333', nombres: 'Lucía Torres',telefono: '3143333333', correo: 'lucia@mail.com',fechaNacimiento: '1995-12-12', sexo: 'F' },

  { id: 6, identificacion: '444444', nombres: 'Jorge Herrera',telefono: '3154444444', correo: 'jorge@mail.com' }
];

app.get('/persona', (req, res) => {
  const dato = req.query.dato?.toLowerCase() || '';
  const resultados = personas.filter(p =>
    p.identificacion.includes(dato) || p.nombres.toLowerCase().includes(dato)
  );
  res.json(resultados);
});

app.listen(3000, () => {
  console.log('API ejecutándose en http://localhost:3000');
});
